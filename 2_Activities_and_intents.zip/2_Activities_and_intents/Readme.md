# 2.1: Activities and intents

* Task 1: Create the TwoActivities project -->*(Project: TwoActivities)*
* Task 2: Create and launch the second Activity -->*(Project: TwoActivities)*
* Task 3: Send data from the main Activity to the second Activity -->*(Project: TwoActivities)*
* Task 4: Return data back to the main Activity -->*(Project: TwoActivities)*
* Coding challenge -->*(Project: threeButtonsTwoActivities)*
* Homework -->*(Project: HelloToastHW1)*
